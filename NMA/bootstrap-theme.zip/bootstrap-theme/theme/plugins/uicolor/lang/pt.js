/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","pt",{title:"Seleção de Cor da IU",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Conjuntos de cor predefinidos",config:"Colar este item no seu ficheiro config.js"});