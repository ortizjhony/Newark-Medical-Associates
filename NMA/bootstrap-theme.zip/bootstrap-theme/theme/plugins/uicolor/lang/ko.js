/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","ko",{title:"UI 색상 선택기",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"미리 정의된 색상",config:"이 문자열을 config.js 에 붙여넣으세요"});